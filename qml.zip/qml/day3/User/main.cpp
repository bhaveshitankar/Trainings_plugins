#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include<QQmlContext>
#include"MyAuth.h"
int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
MyAuth auth;
auth.setUser("Cartoon");
auth.setPass("Welcome123");
auth.verify("Cartoon","Welcome123");
    QQmlApplicationEngine engine;
    QQmlContext *ctx = engine.rootContext();
    ctx->setContextProperty("login",&auth);
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}
