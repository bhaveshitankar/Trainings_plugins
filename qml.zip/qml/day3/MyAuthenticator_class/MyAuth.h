#ifndef MYAUTH_H
#define MYAUTH_H

#include <QObject>
#include<QDebug>
class MyAuth : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString user READ user WRITE setUser NOTIFY userChanged)
public:
    explicit MyAuth(QObject *parent = nullptr);

    QString user() const;
    void setUser(const QString &user);

    QString pass() const;
    void setPass(const QString &pass);

signals:
    void success();
    void fail();
    void userChanged();

public slots:
    void verify(QString u, QString p);
    void display();
private:
    QString m_user;
    QString m_pass;
};

#endif // MYAUTH_H
