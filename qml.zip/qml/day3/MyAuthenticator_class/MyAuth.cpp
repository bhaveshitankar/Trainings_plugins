#include "MyAuth.h"

MyAuth::MyAuth(QObject *parent) : QObject(parent)
{
qDebug()<< Q_FUNC_INFO<<endl;
}

QString MyAuth::user() const
{
    qDebug()<< Q_FUNC_INFO<<endl;
    return m_user;
}

void MyAuth::setUser(const QString &user)
{
    qDebug()<< Q_FUNC_INFO<<endl;
    if(m_user.compare(user)==0) return;
    m_user = user;
    emit userChanged();
}

void MyAuth::verify(QString u, QString p)
{
    qDebug()<<Q_FUNC_INFO<<"User="<<u;
    qDebug()<<Q_FUNC_INFO<<"Password="<<p;
    if(u.compare("Vaishnavi")==0){
        qDebug()<<"success"<<endl;
        emit success();
    }else{qDebug()<<"fail"<<endl;
        emit fail();
    }
}

QString MyAuth::pass() const
{
    qDebug()<< Q_FUNC_INFO<<endl;
    return m_pass;
}

void MyAuth::setPass(const QString &pass)
{
    qDebug()<< Q_FUNC_INFO<<endl;
    m_pass = pass;
}

void MyAuth::display()
{
    qDebug()<<Q_FUNC_INFO<<"User="<<m_user;
    qDebug()<<Q_FUNC_INFO<<"Password="<<m_pass;
}
