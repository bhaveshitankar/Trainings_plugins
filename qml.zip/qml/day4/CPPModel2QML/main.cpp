#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include"SpaceDataModel.h"
#include<QQmlContext>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    SpaceDataModel *da = new SpaceDataModel;
    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty("cppModel",da);
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}
