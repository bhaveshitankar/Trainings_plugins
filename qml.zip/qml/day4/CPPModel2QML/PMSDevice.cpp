#include "PMSDevice.h"

PMSDevice::PMSDevice()
{

}

QString PMSDevice::getName() const
{
    return name;
}

void PMSDevice::setName(const QString &value)
{
    name = value;
}

QString PMSDevice::getPhone() const
{
    return phone;
}

void PMSDevice::setPhone(const QString &value)
{
    phone = value;
}

QString PMSDevice::getEmail() const
{
    return email;
}

void PMSDevice::setEmail(const QString &value)
{
    email = value;
}

QString PMSDevice::getMycompany() const
{
    return mycompany;
}

void PMSDevice::setMycompany(const QString &value)
{
    mycompany = value;
}
