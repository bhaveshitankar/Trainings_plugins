#ifndef SPACEDATAMODEL_H
#define SPACEDATAMODEL_H
#include<QAbstractListModel>
#include<QDebug>
#include"PMSDevice.h"
#include<QList>

class SpaceDataModel : public QAbstractListModel
{
    Q_OBJECT
public:
    SpaceDataModel();
    int rowCount(const QModelIndex &idx)const;
    int columnCount(const QModelIndex &idx)const;
    QVariant data(const QModelIndex &idx,int role)const;
    //v-func reqd for QML
    QHash<int, QByteArray> roleNames()const;
private:
    QList<PMSDevice*> m_dev;
};

#endif // SPACEDATAMODEL_H
