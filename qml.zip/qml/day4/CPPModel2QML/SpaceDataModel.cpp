#include "SpaceDataModel.h"
#include"PMSDevice.h"
SpaceDataModel::SpaceDataModel()
{
    PMSDevice *d1 = new PMSDevice;
    d1->setName("Akash");
    d1->setPhone("123456789");
    d1->setEmail("giwu@uydfgu.com");
    d1->setMycompany("lnt");
    PMSDevice *d2 = new PMSDevice;
    d2->setName("Meenakshi");
    PMSDevice *d3 = new PMSDevice;
    d3->setName("Vaishnavi");
    PMSDevice *d4 = new PMSDevice;
    d4->setName("Pooja");
    PMSDevice *d5 = new PMSDevice;
    d5->setName("Anusha");
    PMSDevice *d6 = new PMSDevice;
    d6->setName("Kavya");

    m_dev.append(d1);
    m_dev.append(d2);
    m_dev.append(d3);
    m_dev.append(d4);
    m_dev.append(d5);
    m_dev.append(d6);
    qDebug()<<Q_FUNC_INFO<<endl;
}

int SpaceDataModel::rowCount(const QModelIndex &idx) const
{
    qDebug()<<Q_FUNC_INFO<<endl;
   return 5;
}

int SpaceDataModel::columnCount(const QModelIndex &idx) const
{
     qDebug()<<Q_FUNC_INFO<<endl;
    return 2;
}

QVariant SpaceDataModel::data(const QModelIndex &idx, int role) const
{
     qDebug()<<Q_FUNC_INFO<<endl;
     qDebug()<<"Row= "<<idx.row()<<"Column= "<<idx.column()<<endl;
     qDebug()<<"Role no= "<<role<<endl;
    QVariant da = "SpaceModel";
    PMSDevice *d1 = m_dev.at(idx.row());
    switch(role){
    case 0:
        da = d1->getName();
        break;
    case 1:
        da = d1->getPhone();
        break;
    case 2:
        da = d1->getEmail();
        break;
    case 3:
        da = d1->getMycompany();
        break;
    default:
        da = "TCS";
        break;
    }

    return da;
}
//QVariant SpaceDataModel::data_1(const QModelIndex &idx, int role) const
//{
//     qDebug()<<Q_FUNC_INFO<<endl;
//     qDebug()<<"Row= "<<idx.row()<<"Column= "<<idx.column()<<endl;
//     qDebug()<<"Role no= "<<role<<endl;
//    QVariant da = "SpaceModel";
//    switch(role){
//    case 0:
//        da = "Ravindra";
//        break;
//    case 1:
//        da = "845697456";
//        break;
//    case 2:
//        da = "ravindra.s@ltts.com";
//        break;
//    case 3:
//        da = "TST3";
//        break;
//    }

//    return da;
//}
QHash<int, QByteArray> SpaceDataModel::roleNames() const
{
    QHash<int, QByteArray>props;
    qDebug()<<Q_FUNC_INFO<<endl;
    props[0]="name";
    props[1]="phone";
    props[2]="email";
    //or
    props.insert(3,"cName");
    return props;

}
