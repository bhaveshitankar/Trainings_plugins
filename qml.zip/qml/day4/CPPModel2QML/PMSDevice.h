#ifndef PMSDEVICE_H
#define PMSDEVICE_H

#include<QString>
class PMSDevice
{
public:
    PMSDevice();

    QString getName() const;
    void setName(const QString &value);

    QString getPhone() const;
    void setPhone(const QString &value);

    QString getEmail() const;
    void setEmail(const QString &value);

    QString getMycompany() const;
    void setMycompany(const QString &value);

private:
    QString name;
    QString phone;
    QString email;
    QString mycompany;

};

#endif // PMSDEVICE_H
