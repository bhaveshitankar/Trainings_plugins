Garry's Mod 10 Lua Syntax Highlighter Plugin
created by Kyle Fleming (aka Garthex)
email: garthex AT gmail.com

For more information, please visit:

Official SVN/Wiki hosting-
http://code.google.com/p/npp-gmod-lua/


Facepunch forum release thread-
http://forums.facepunchstudios.com/showthread.php?p=8625735

SourceForge.net download page-
https://sourceforge.net/project/showfiles.php?group_id=189927&package_id=265782





Special Thanks for borrowed code:

Thell Fowler
Robert Roessler
Paul Winwood
Alexey Yutkin
Marcos E. Wurzius
Philippe Lhoste